#define NA -98.7654321
