library(testthat)
test_package("shinyAce")